#ifndef MULTI_LOOKUP_H
#define MULTI_LOOKUP_H

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include "queue.h"
#include "util.h"

#define MAX_INPUT_FILES 10
#define MAX_RESOLVER_THREADS 10
#define MAX_REQUESTER_THREADS 5
#define MAX_NAME_LENGTH 1025
#define MAX_IP_LENGTH INET6 ADDRSTRLEN

#define Sucess 0
#define Fail -1

#define Queue_Size 10
#define INPUTFS "%1024s"
#define CHARBUFFER 1025
#define MINARG 5
#define USAGE "<# requester> <# resolver> <requester log> <resolver log> [ <data file> ...(limit 10 files)]"

pthread_mutex_t mQueue;
pthread_mutex_t mRequest;
pthread_cond_t halfFull;
pthread_cond_t halfEmpty;
queue q;
double count;
bool remain;
int countServe;
void* multiThread_requester(void* input);
void* multiThread_resolver(void* input);

#endif
