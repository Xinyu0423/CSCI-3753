#include <stdlib.h>
#include <string.h>
#include "queue.h"

int queue_init(queue* q, int maxSize){
	q->list=malloc(sizeof(queue_data)*(q->size));
	if(!(q->list)){
		fprintf(stderr, "error on malloc");
		return 0;

	}
	for(int i=0;i<maxSize;++i){
		q->list[i].data=NULL;
	}
	q->start=0;
	q->end=0;
	q->size=maxSize;
	return maxSize;
}

int queue_is_empty(queue* q){
	if((q->start==q->end) && (q->list[q->start].data==NULL)){
		return 1;
	}else{
		return 0;
	}
}
int queue_is_full(queue* q){
	if((q->start==q->end) && (q->list[q->start].data!=NULL)){
		return 1;
	}else{
		return 0;
	}
}
int queue_push(queue *q, void* data){
	if(queue_is_full(q)){
		return 0;
	}else{
		q->list[q->end].data=data;
		q->end=((q->end+1)%(q->size));
		return QUEUE_SUCCESS;
	}
}
void* queue_pop(queue* q){
	void* temp=NULL;
	if(queue_is_empty(q)){
		return NULL;
	}else{
		temp=q->list[q->start].data;
		q->list[q->start].data=NULL;
		q->start=((q->start+1)%(q->size));
		return temp;
	}
}
void queue_cleanup(queue* q){
	while(!(queue_is_empty)){
		queue_pop(q);
	}
	free(q->list);
}