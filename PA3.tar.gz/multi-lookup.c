#include "multi-lookup.h"
#include "queue.h"
//Citation:
//https://github.com/TopherGopher/OS-DNS-Multilookup/blob/master/multi-lookup.c
//https://github.com/evankkerns/csci3753/blob/master/multi-lookup.c

void* multiThread_requester(void* input){

	pid_t tid=syscall(SYS_gettid);
	FILE* inputFile=NULL;
	//printf("a\n");
	countServe+=1;
	char buffer_req[MAX_NAME_LENGTH];
	FILE* servicedFile=fopen("serviced.txt","a");
	if(!servicedFile){
		printf("open file error\n");
		return 0;
	}
	char* fName=(char*) input;
	inputFile=fopen(fName,"r");
	if(!inputFile){
		printf("open file error\n");
		return 0;
	}
	char* hostN=(char*) malloc(CHARBUFFER);
	//fprintf(servicedFile, "Thread %d has serviced %s",tid,fName);
	bool done=false;
	int num_req=0;
	countServe++;
	while(fscanf(inputFile,INPUTFS,hostN)>0){
		pthread_mutex_lock(&mQueue);
		if(queue_is_full(&q)){
			//printf("queue is full\n");
			pthread_cond_wait(&halfFull, &mQueue);
		}
		//printf("a\n");
		if(queue_push(&q,(void*)hostN)==QUEUE_FAILURE){
			fprintf(stderr,"Queue is full. Cannot enter more data %s\n",hostN);
		}
		//printf("b\n");
		//pthread_cond_signal(&halfFull);
		done=true;
		pthread_mutex_unlock(&mQueue);
		hostN = (char*) malloc(CHARBUFFER);
		num_req++;
	}
	fprintf(servicedFile, "Thread %d has serviced %d files\n",tid,countServe);
	fclose(servicedFile);
	count--;
	fclose(inputFile);
	free(hostN);
	hostN=NULL;
	pthread_exit(NULL);
	return NULL;
}

void* multiThread_resolver(void* input){
	FILE* outputFile=NULL;
	char firstIPStr[MAX_NAME_LENGTH];
	char* hostName=(char*) malloc(CHARBUFFER);
	outputFile=fopen((char*) input,"a");
	if(!outputFile){
		printf("open file error\n");
		return 0;
	}
	remain=true;
	int countEmpty=0;
	//while(remain==true || !queue_is_empty(&q)){
	while(remain==true || !queue_is_empty(&q)){
		pthread_mutex_lock(&mQueue);
		if(queue_is_empty(&q)){
			countEmpty++;
		//	printf("Queue is empty");
			//pthread_cond_wait(&halfFull, &mQueue);
		}
		if((hostName=(char*)queue_pop(&q))==NULL){
			pthread_mutex_unlock(&mQueue);
			pthread_cond_signal(&halfFull);
		}else{
			pthread_mutex_unlock(&mQueue);
			if(dnslookup(hostName,firstIPStr,sizeof(firstIPStr))==UTIL_FAILURE){
				fprintf(stderr, "error on dnslookup: %s\n",hostName);
				strncpy(firstIPStr, "", sizeof(firstIPStr));
				//copy from source to destin
				//char *strncpy(char *destinin, char *source, int maxlen);
			}
			pthread_mutex_lock(&mRequest);
			fprintf(outputFile, "%s,%s\n",hostName,firstIPStr );
			pthread_mutex_unlock(&mRequest);
			free(hostName);
			hostName=NULL;
		}
	}
	pthread_mutex_lock(&mQueue);
	if(queue_is_empty(&q)){
		pthread_mutex_unlock(&mQueue);
		pthread_exit(NULL);
		return NULL;
	}else{
		fprintf(stderr, "Queue is NOT empty - THIS IS A PROBLEM\n");
		pthread_mutex_unlock(&mQueue);
		return NULL;
	}
	return NULL;
}
int main(int argc, char const *argv[]){
	struct timeval start, end;
	//printf("Number for requester thread %d\n",argv[1] );
	//printf("resolver thread: %d\n",argv[2] );
    gettimeofday(&start, NULL);
    long long millisecondStart = start.tv_sec*1000LL + start.tv_usec/1000;
	int reqNum=atoi(argv[1]);
	int resNum=atoi(argv[2]);
	printf("Number for requester thread = %d\n",reqNum );
	printf("Number for resolver thread = %d\n",resNum );
	count=argc-5;
	int countFiles=argc-5;
	pthread_t requester[atoi(argv[1])];
	pthread_t resolver[atoi(argv[2])];

    pthread_mutex_init(&mQueue, NULL);
    pthread_mutex_init(&mRequest, NULL);
	pthread_cond_init(&halfFull, NULL);
	pthread_cond_init(&halfEmpty, NULL);
	queue_init(&q, -1);
	if(argc<MINARG){
		fprintf(stderr, "No enough arguments\n");
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		queue_cleanup(&q);
		return 0;
	}else if(argc>MAX_INPUT_FILES){
		fprintf(stderr, "Too many arguments\n");
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		queue_cleanup(&q);
		return 0;
	}
	if(reqNum>MAX_REQUESTER_THREADS){
		fprintf(stderr, "Reach the max requester thread\n");
		return 0;
	}if(resNum>MAX_RESOLVER_THREADS){
		fprintf(stderr, "Reach the max resolver thread\n");
		return 0;
	}
	
	int tempReq;
	printf("first loop\n");
	for(int i=0;i<reqNum;i++){
		tempReq=pthread_create(&(requester[i]), NULL, multiThread_requester, (void *)argv[i+5]);
		if(tempReq!=0){
			//printf("1\n");
			printf("Cannot create requester thread\n");
			//queue_cleanup(&q);
			return 0;
		}
	}
	int tempRes;
	printf("second loop\n");
	for(int i=0;i<resNum;i++){
		tempRes=pthread_create(&(resolver[i]), NULL, multiThread_resolver, (void *)argv[4]);
		if(tempRes!=0){
			printf("Cannot create resolver thread\n");
			//queue_cleanup(&q);
			return 0;
		}
	}
	printf("third loop\n");
	for(int i=0;i<reqNum;i++){
		pthread_join(requester[i], NULL);
	}
	remain=false;
	printf("fourth loop\n");
	for(int i=0;i<resNum;i++){
		pthread_join(resolver[i], NULL);
	}
	queue_cleanup(&q);
	pthread_mutex_destroy(&mQueue);
    pthread_mutex_destroy(&mRequest);
    //gettimeofday(&end, NULL);
    gettimeofday(&end, NULL);
    long long millisecondEnd = end.tv_sec * 1000LL + end.tv_usec / 1000;
    fprintf(stderr, "Total runtime: %lld milliseconds\n",millisecondEnd-millisecondStart);
	return 0;
	
}